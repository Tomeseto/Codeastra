# VARSHA — Real Data Package
**Generated:** 2026-10-09 22:41 IST  
**For:** VARSHA prototype builder  
**Project:** CODEASTRA 2.0 — RGIT Mumbai  

## What's in this folder

| File | Contents | Status |
|---|---|---|
| `rain_jul2026_daily.json` | Daily rain/temp/RH at Mumbai Santacruz grid, Jun 20 – Jul 31 2026 | ✅ Live |
| `rain_aug2025_grid.json` | Aug–Sep 2025 (includes 245mm event) | ✅ Live |
| `rain_2005deluge_grid.json` | Jul 2005 (note: grid shows 69mm vs real 944mm — use NOAA for calibration) | ✅ Live |
| `rain_training_2010_2025_daily.json` | 15 years of daily data for model training | ✅ Live |
| `forecast_live.json` | 16-day live forecast (fetched today) | ✅ Live |
| `noaa_2005deluge.json` | NOAA station data Jul–Aug 2005; 26 Jul = 461mm (18.15in) | ✅ Live |
| `noaa_aug2025.json` | NOAA station data Aug–Sep 2025; 16 Aug = 245mm | ✅ Live |
| `noaa_history_2000_2025.json` | 25 years of daily station data for bias calibration | ✅ Live |
| `noaa_2026.json` | 2026 station data — EMPTY (not yet published by NOAA) | ⚠️ Empty |
| `who_don_latest100.json` | 100 latest WHO Disease Outbreak News | ✅ Live |
| `gdelt_lepto_mumbai.json` | GDELT news: leptospirosis Mumbai monsoon | ✅ Live |
| `gdelt_dengue_mumbai.json` | GDELT news: dengue Mumbai 2026 | ✅ Live |
| `gdelt_malaria_mumbai.json` | GDELT news: malaria Mumbai flood | ✅ Live |
| `gdelt_flood_outbreak.json` | GDELT news: Mumbai flood waterlogging disease | ✅ Live |
| `gdelt_bmc_advisory.json` | GDELT news: BMC leptospirosis 72-hour advisory | ✅ Live |
| `mumbai_wards_24.json` | 24 ward data: population, slum fraction, hotspot counts, vulnerability | ✅ Compiled |
| `mumbai_wards_24.csv` | Same as above, CSV format | ✅ Compiled |
| `mumbai_wards_centroids.geojson` | GeoJSON point features for MapLibre | ✅ Compiled |
| `waterlogging_hotspots.json` | 25 geocoded BMC flood hotspots (of 386 total) | ⚠️ Partial |
| `aapla_dawakhana_clinics.json` | 20 geocoded Aapla Dawakhana clinics (of ~200 total) | ⚠️ Partial |
| `bmc_disease_series.json` | BMC monsoon disease counts 2023–2026 (from press) | ✅ Compiled |
| `varsha_alert_tiers.json` | Watch/Warning/Emergency tiers + IMD thresholds + multilingual messages | ✅ Compiled |
| `exposure_model_spec.json` | Ward Exposure Index formula, parameters, lag kernel, surge model | ✅ Compiled |
| `research_evidence.json` | Key papers: Supe 2018, Costa 2015, IITM 2025, etc. | ✅ Compiled |
| `idsp_access_guide.json` | IDSP Dataful download guide + column names + filter script | ✅ Compiled |
| `ward_forecasts_live.json` | Live 7-day forecast for 5 ward centroids | ✅ Live |
| `tech_stack.json` | Full tech stack spec for prototype | ✅ Compiled |
| `fetch_log.json` | API call log with status | ✅ |

## Next steps for the prototype builder

### MUST DO before hackathon
1. **Download IDSP CSV** from https://dataful.in/datasets/18514 → save as `idsp_master.csv` → run filter script in `idsp_access_guide.json`
2. **Get Telegram Bot token** → @BotFather → `/newbot` → copy token → set `TELEGRAM_TOKEN` env var
3. **Apply for IMD API whitelisting** → https://city.imd.gov.in/citywx/api_request.php (lead time unknown; Open-Meteo is the fallback)
4. **Get full ward GeoJSON polygons** → https://github.com/mickeykedia/India-Maps or https://projects.datameet.org/Municipal_Spatial_Data/

### KEY DATA FACTS to hardcode for the Time Machine demo
- **1–7 Jul 2026 total rain (grid):** ~596mm (see `rain_jul2026_daily.json`)
- **1–7 Jul 2026 real station rain:** ~984mm (IMD/press)
- **26 Jul 2005 grid:** 69.6mm; **station:** 461mm (NOAA); **IMD:** ~944mm
- **16 Aug 2025 station:** 245mm; **20 Aug 2025:** 209mm
- **BMC advisory:** 6 Jul 2026, 22:39 IST
- **Cases:** Leptospirosis 33 (June 2026) → 78 (July 2026) = +136%

### Rainfall unit conversion
- NOAA GSOD PRCP is in **inches** → multiply by **25.4** for mm
- Open-Meteo is already in **mm**

### Bias calibration (critical)
Use `noaa_history_2000_2025.json` + `rain_training_2010_2025_daily.json` to fit a quantile map.
The 2005 event shows a 13× underestimate (69.6mm grid vs 944mm station).

### Ward vulnerability ranking (top risk wards)
Based on slum fraction × flood hotspot density:
1. L (Kurla/Sakinaka) — highest hotspot density + large slum pop
2. K/E (Andheri East) — high hotspots, large area
3. M/E (Chembur/Govandi) — high slum fraction
4. G/N (Dharavi) — highest slum density
5. H/E (Bandra East) — chronic hotspots + population

## Sources
- Open-Meteo: https://open-meteo.com/ (CC BY 4.0)
- NOAA GSOD: https://www.ncei.noaa.gov/access/services/data/v1 (public domain)
- IDSP: https://dataful.in/datasets/18514 (Factly/IDSP, CC BY 4.0)
- BMC series: compiled from press releases (URLs in bmc_disease_series.json)
- Ward census: MCGM Census FAQ PDF 2011
- Research papers: see research_evidence.json for full URLs
